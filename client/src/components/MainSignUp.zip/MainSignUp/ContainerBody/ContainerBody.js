import React, { Component } from 'react';
import style from './ContainerBody.module.scss';
import Form from './Form/Form';
import { SubmissionError } from 'redux-form';
import { userLogin } from '../../../actions/actionCreator';
import connect from 'react-redux/es/connect/connect';

const yup = require('yup');
const schema = require('../../../models/userSchema');
const sleep = ms => new Promise(resolve => resolve());
let resEmail;

class ContainerBody extends Component {

  submit = (values) => {
    const errors = {};
    return sleep(200).then(async () => {
      console.log("VALUES ",values,values.DisplayName==="s");
      try {
        resEmail = await yup.reach(schema, 'email').isValid(values.email);

      } catch (e) {
      }
      if (values.DisplayName==="s") {
        errors.email='DisplayName is not valid format';
        throw new SubmissionError({
          DisplayName: 'DisplayName is not valid format',
          _error: 'Login failed!',
        });
      }
      else if (!resEmail) {

        errors.email='Email is not valid format';

        throw new SubmissionError({
          email: 'Email is not valid format',
          _error: 'Login failed!',
        });
      }
      const dataToSend = {
        email: values.email,
        password: values.password,
      };

      //this.props.userLogin(dataToSend);
    });
  return errors
  };

  render() {
    return (
      <div className={style.main}>
        <div className={style.title}><h2>CREATE AN ACCOUNT</h2></div>
        <div className={style.subTitle}><h4>We always keep your name and email address private.</h4></div>
        <div className={style.mainForm}>
          <Form onSubmit={this.submit}/>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    state,
    fromStore: state.userReducers.data,
  };
};
const mapDispatchToProps = (dispatch) => ({
  userLogin: (dataToSend) => dispatch(userLogin(dataToSend)),
});
export default connect(mapStateToProps, mapDispatchToProps)(ContainerBody);

